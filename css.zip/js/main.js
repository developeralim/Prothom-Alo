(function() {
        var colombiaPixelURL = "https://ade.clmbtech.com/cde/eventTracking.htm?pixelId=11034&_w=1&rd=" + new Date().getTime();
        (new Image()).src = colombiaPixelURL;
    }

)();

_atrk_opts = {
    atrk_acct: "VTJem1aIF5R1fn",
    domain: "prothomalo.com",
    dynamic: true
}

;
(function() {
        var as = document.createElement('script');
        as.type = 'text/javascript';
        as.async = true;
        as.src = "https://certify-js.alexametrics.com/atrk.js";
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(as, s);
    }

)();

(function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            "gtm.start": new Date().getTime(),
            event: "gtm.js"
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != "dataLayer" ? "&l=" + l : "";
        j.async = true;
        j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
        f.parentNode.insertBefore(j, f);
    }

)(window, document, "script", "dataLayer", "GTM-TDCC7GQ");

! function(e) {
    var t = {};

    function n(o) {
        if (t[o]) return t[o].exports;
        var i = t[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return e[o].call(i.exports, i, i.exports, n),
            i.l = !0,
            i.exports
    }
    n.m = e,
        n.c = t,
        n.d = function(e, t, o) {
            n.o(e, t) || Object.defineProperty(e, t, {
                enumerable: !0,
                get: o
            })
        },
        n.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module"
                }),
                Object.defineProperty(e, "__esModule", {
                    value: !0
                })
        },
        n.t = function(e, t) {
            if (1 & t && (e = n(e)), 8 & t) return e;
            if (4 & t && "object" == typeof e && e && e.__esModule) return e;
            var o = Object.create(null);
            if (n.r(o), Object.defineProperty(o, "default", {
                    enumerable: !0,
                    value: e
                }), 2 & t && "string" != typeof e)
                for (var i in e) n.d(o, i, function(t) {
                        return e[t]
                    }
                    .bind(null, i));
            return o
        },
        n.n = function(e) {
            var t = e && e.__esModule ? function() {
                    return e.default
                } :
                function() {
                    return e
                };
            return n.d(t, "a", t),
                t
        },
        n.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        },
        n.p = "/prothomalo/assets/",
        n(n.s = 243)
}

({
        10: function(e, t) {
            var n;
            n = function() {
                    return this
                }
                ();
            try {
                n = n || new Function("return this")()
            } catch (e) {
                "object" == typeof window && (n = window)
            }
            e.exports = n
        },
        150: function(e, t, n) {
            ! function() {
                function t(e, t) {
                    document.addEventListener ? e.addEventListener("scroll", t, !1) : e.attachEvent("scroll", t)
                }

                function n(e) {
                    this.a = document.createElement("div"), this.a.setAttribute("aria-hidden", "true"), this.a.appendChild(document.createTextNode(e)), this.b = document.createElement("span"), this.c = document.createElement("span"), this.h = document.createElement("span"), this.f = document.createElement("span"), this.g = -1, this.b.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.c.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.f.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.h.style.cssText = "display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;", this.b.appendChild(this.h), this.c.appendChild(this.f), this.a.appendChild(this.b), this.a.appendChild(this.c)
                }

                function o(e, t) {
                    e.a.style.cssText = "max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;white-space:nowrap;font-synthesis:none;font:" + t + ";"
                }

                function i(e) {
                    var t = e.a.offsetWidth,
                        n = t + 100;
                    return e.f.style.width = n + "px", e.c.scrollLeft = n, e.b.scrollLeft = e.b.scrollWidth + 100, e.g !== t && (e.g = t, !0)
                }

                function r(e, n) {
                    function o() {
                        var e = r;
                        i(e) && e.a.parentNode && n(e.g)
                    }
                    var r = e;
                    t(e.b, o), t(e.c, o), i(e)
                }

                function a(e, t) {
                    var n = t || {};
                    this.family = e, this.style = n.style || "normal", this.weight = n.weight || "normal", this.stretch = n.stretch || "normal"
                }
                var s = null,
                    c = null,
                    d = null,
                    l = null;

                function u() {
                    return null === l && (l = !!document.fonts), l
                }

                function f() {
                    if (null === d) {
                        var e = document.createElement("div");
                        try {
                            e.style.font = "condensed 100px sans-serif"
                        } catch (e) {}
                        d = "" !== e.style.font
                    }
                    return d
                }

                function h(e, t) {
                    return [e.style, e.weight, f() ? e.stretch : "", "100px", t].join(" ")
                }
                a.prototype.load = function(e, t) {
                    var i = this,
                        a = e || "BESbswy",
                        d = 0,
                        l = t || 3e3,
                        f = (new Date).getTime();
                    return new Promise((function(e, t) {
                        if (u() && ! function() {
                                if (null === c)
                                    if (u() && /Apple/.test(window.navigator.vendor)) {
                                        var e = /AppleWebKit\/([0-9]+)(?: \.([0-9]+))(?: \.([0-9]+))/.exec(window.navigator.userAgent);
                                        c = !!e && 603 > parseInt(e[1], 10)
                                    } else c = !1;
                                return c
                            }
                            ()) {
                            var p = new Promise((function(e, t) {
                                    ! function n() {
                                        (new Date).getTime() - f >= l ? t(Error(l + "ms timeout exceeded")) : document.fonts.load(h(i, '"' + i.family + '"'), a).then((function(t) {
                                            1 <= t.length ? e() : setTimeout(n, 25)
                                        }), t)
                                    }
                                    ()
                                })),
                                m = new Promise((function(e, t) {
                                    d = setTimeout((function() {
                                        t(Error(l + "ms timeout exceeded"))
                                    }), l)
                                }));
                            Promise.race([m, p]).then((function() {
                                clearTimeout(d), e(i)
                            }), t)
                        } else ! function(e) {
                                document.body ? e() : document.addEventListener ? document.addEventListener("DOMContentLoaded", (function t() {
                                    document.removeEventListener("DOMContentLoaded", t), e()
                                })) : document.attachEvent("onreadystatechange", (function t() {
                                    "interactive" != document.readyState && "complete" != document.readyState || (document.detachEvent("onreadystatechange", t), e())
                                }))
                            }
                            ((function() {
                                function c() {
                                    var t;
                                    (t = -1 != v && -1 != y || -1 != v && -1 != w || -1 != y && -1 != w) && ((t = v != y && v != w && y != w) || (null === s && (t = /AppleWebKit\/([0-9]+)(?: \.([0-9]+))/.exec(window.navigator.userAgent), s = !!t && (536 > parseInt(t[1], 10) || 536 === parseInt(t[1], 10) && 11 >= parseInt(t[2], 10))), t = s && (v == b && y == b && w == b || v == x && y == x && w == x || v == g && y == g && w == g)), t = !t), t && (E.parentNode && E.parentNode.removeChild(E), clearTimeout(d), e(i))
                                }
                                var u = new n(a),
                                    p = new n(a),
                                    m = new n(a),
                                    v = -1,
                                    y = -1,
                                    w = -1,
                                    b = -1,
                                    x = -1,
                                    g = -1,
                                    E = document.createElement("div");
                                E.dir = "ltr", o(u, h(i, "sans-serif")), o(p, h(i, "serif")), o(m, h(i, "monospace")), E.appendChild(u.a), E.appendChild(p.a), E.appendChild(m.a), document.body.appendChild(E), b = u.a.offsetWidth, x = p.a.offsetWidth, g = m.a.offsetWidth,
                                    function e() {
                                        if ((new Date).getTime() - f >= l) E.parentNode && E.parentNode.removeChild(E), t(Error(l + "ms timeout exceeded"));
                                        else {
                                            var n = document.hidden;
                                            !0 !== n && void 0 !== n || (v = u.a.offsetWidth, y = p.a.offsetWidth, w = m.a.offsetWidth, c()), d = setTimeout(e, 50)
                                        }
                                    }
                                    (), r(u, (function(e) {
                                        v = e, c()
                                    })), o(u, h(i, '"' + i.family + '",sans-serif')), r(p, (function(e) {
                                        y = e, c()
                                    })), o(p, h(i, '"' + i.family + '",serif')), r(m, (function(e) {
                                        w = e, c()
                                    })), o(m, h(i, '"' + i.family + '",monospace'))
                            }))
                    }))
                }, e.exports = a
            }
            ()
        },
        243: function(e, t, n) {
            "use strict";
            n.r(t),
                function(e) {
                    var t = n(150),
                        o = n.n(t);
                    e.loadFonts = function(e, t) {
                        var n = e.map((function(e) {
                            var t = e.fontName,
                                n = e.data;
                            return new o.a(t, n).load()
                        }));
                        Promise.all(n).then((function() {
                            document.body.classList.add(t)
                        })).catch((function(e) {
                            console.warn("Some critical font are not available: ".concat(e, " "))
                        }))
                    }
                }
                .call(this, n(10))
        }
    }

);
//# sourceMappingURL=font-08345f214929c885f8b3.js.map
window.loadFonts([{
        "fontName": "Shurjo",
        "data": {
            "weight": 400
        }
    }

    , {
        "fontName": "Shurjo",
        "data": {
            "weight": 700
        }
    }

], 'fonts-loaded');


if (!window.fetch || !window.Array.prototype.map || !window.Promise || !window.URLSearchParams || !window.IntersectionObserver || !window.Set) {
    s = document.createElement('script');
    s.type = 'text/javascript';
    s.src = 'https://cdn.polyfill.io/v2/polyfill.min.js?features=default,IntersectionObserver,fetch';
    document.getElementsByTagName('head')[0].appendChild(s);
}
window.addEventListener('appinstalled', (event) => {
        if ('function' === typeof ga) {
            // Default GA.
            ga('send', 'event', 'pwa', 'install');
        } else if ('function' === typeof __gaTracker) {
            // MonsterInsights.
            __gaTracker('send', 'event', 'pwa', 'install');
        }
    }

);

window._peq = window._peq || [];
window._peq.push(["init"]);

// custom js
document.querySelector(".hamburger-m__hamburger__2Oc5s").addEventListener("click", () => {
    document.querySelector(".vertical-menubar-wrapper").style.display = "block";
});
document.querySelector(".button-close").addEventListener("click", () => {
    document.querySelector(".vertical-menubar-wrapper").style.display = "none";
});
var searchIconWraper = document.querySelector(".search-icon-wrapper");
searchIconWraper.addEventListener("click", () => {


    if (searchIconWraper.classList.contains('sc-active')) {
        searchIconWraper.classList.remove('sc-active');
        document.querySelector(".staticHeader-m__navbar-search__1kH7F").innerHTML = ``;
        searchIconWraper.innerHTML = `<i class="fa-solid fa-magnifying-glass"></i>`;
    } else {
        searchIconWraper.classList.add('sc-active');
        document.querySelector(".staticHeader-m__navbar-search__1kH7F").innerHTML = `<div class="search navbarSearch-m__search__2hkfU navbarSearch-m__desktop__1aXlg">
            <form role="search" action="/search" class="search-box navbarSearch-m__search-box__d50H6">
                <label for="searchForm" class="search-label navbarSearch-m__search-label__2svEr">
                <input type="search" name="q" placeholder=" যা খুঁজতে চান" class="search__form-input bn-search__form-input" id="searchForm" value="">
                </label>
                <button type="submit" class="search__form-submit navbarSearch-m__search__form-submit__1OukE">
                <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
        </div>`;
        searchIconWraper.innerHTML = `<i class="fa-solid fa-xmark"></i>`;
    }
});